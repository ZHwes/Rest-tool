# IDM trial reset

Use IDM forever without cracking

## Screenshot

![idm-trial-reset](https://i.imgur.com/xUGaHMK.gif)

## Credits

- [idmresettrial](http://www.vn-zoom.com/8222251-idmresettrial/) (original author)
- [Helge Klein](https://helgeklein.com/) (for SetACL)

## License

[MIT](LICENSE) License.